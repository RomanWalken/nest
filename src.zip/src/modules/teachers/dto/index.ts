export * from './create-teacher.dto';
export * from './update-teacher.dto';
export * from './query-teacher.dto';
