import { SetMetadata } from '@nestjs/common';
import { UserRole } from '@/common/types';

export const Roles = (...roles: UserRole[]) => SetMetadata('roles', roles); 